import re
import os.path
import shutil
CONTENTPATCH = r"C:\Program Files (x86)\Steam\steamapps\common\GarrysMod\garrysmod\addons\gm_metro_minsk_1984"
OUTPUTCONTENTPATCH = r"C:\Users\user\Desktop\institut"
MAPFILE = r"\maps\institut.vmf"

def checkfile(patchname):
    if os.path.exists(patchname):
        return(True);
    else:
        return(False);

def getmaterialsformdl(patchname):
    output = [];
    try:
        with open(patchname, "rb") as f :
            patch = "";
            for byteinfo in f:
                binfo3 = re.findall(r'[\\0-9_a-zA-Z]+', byteinfo.decode('ascii', errors='ignore'))
                for item2 in binfo3:
                    if item2.lower() == "idle":
                        patch = binfo3[len(binfo3)-1];
                        break;
                for item2 in binfo3:
                    if item2.lower() == "idle":
                        index0 = binfo3.index("idle", 1, len(binfo3))
                        im = 0;
                        while (im < (len(binfo3) - (index0+3))-1 ):
                            zpatch = ("materials\\" + patch + binfo3[index0+3+im]+".vmt").replace("\\","/");
                            output.append(zpatch)
                            im = im + 1;
                        break;
            f.close();
        output.sort();
        return(output);   
    except FileNotFoundError:
        returnfalse = ["fnferror", patchname];
        return(returnfalse)

	
def checkinmassive(line, massive):
    for item in massive:
        if item == line:
            return True;
    return False;

def getvtfromvmt(patchname):
    vtfoutput = [];
    try:
        with open(patchname,"r",encoding='UTF-8') as vmtfile:
            for vmtline in vmtfile:
                vmtlinesplted = vmtline.split(' ');
                if len(vmtlinesplted) > 1:
                     if (vmtline.find("basetexture") > 0) or (vmtline.find("bumpmap") > 0) or (vmtline.find("selfillummask") > 0) or (vmtline.find("envmapmask") > 0) or (vmtline.find("detail") > 0):
                        if len(vmtlinesplted[len(vmtlinesplted)-1]) > 2:
                            vmtlinesplted2 = re.findall(r'[/0-9_a-zA-Z]+', vmtlinesplted[len(vmtlinesplted)-1])
                            if vmtlinesplted2:
                                 vtfoutput.append("materials/" + vmtlinesplted2[0]+".vtf");
        vmtfile.close();
        vtfoutput.sort();
        return(vtfoutput);
    except FileNotFoundError:
        returnfalse = ["fnferror", patchname];
        return(returnfalse)

def getmdlfrommap(patchname):
    output = [];
    mapfile = open(CONTENTPATCH + patchname,"r",encoding='UTF-8');
    for mapfileline in mapfile:
        indexline = mapfileline.find(".mdl");
        if indexline != -1:
            splittedmapline = mapfileline.split('"')[3];
            if checkinmassive(splittedmapline,output) == False:
                output.append(splittedmapline);
    mapfile.close();
    output.sort();
    return(output);

def getmaterialsfrommap(patchname):
    output = [];
    mapfile = open(CONTENTPATCH + patchname,"r",encoding='UTF-8');
    for mapfileline in mapfile:
        indexline = mapfileline.find('"material"');
        if indexline != -1:
            splittedmapline = mapfileline.split(' ')[1].split('"')[1].lower().lstrip('/') + ".vmt";
            splittedmapline = "materials/" + splittedmapline
            if checkinmassive(splittedmapline,output) == False:
                output.append(splittedmapline);
    return(output);
	
def checkandcreatefolders(patchname):
    gg = patchname.split('/');
    svod = "";
    for fa in gg:
        svod = svod + fa + "/";
        if os.path.isdir(svod) == False:
            os.mkdir(svod);

allfileslist = []
print("Поиск контента для моделей...");
for mdlcycleline in getmdlfrommap(MAPFILE):
    if checkfile(CONTENTPATCH + "/" + mdlcycleline):
        print(mdlcycleline)
        if checkinmassive(mdlcycleline,allfileslist) == False:
            allfileslist.append(mdlcycleline);
        for vmtcycleline in getmaterialsformdl(CONTENTPATCH + "/" + mdlcycleline):
            if checkfile(CONTENTPATCH + "/" + vmtcycleline):
                print("\t" + vmtcycleline)
                if checkinmassive(vmtcycleline,allfileslist) == False:
                    allfileslist.append(vmtcycleline);
                for vtfcycleline in getvtfromvmt(CONTENTPATCH + "/" + vmtcycleline):
                    if checkfile(CONTENTPATCH + "/" + vtfcycleline):
                        print("\t\t" + vtfcycleline);
                        if checkinmassive(vtfcycleline,allfileslist) == False:
                            allfileslist.append(vtfcycleline);
                    else:
                        print("\t\t" + "File not found: " + vtfcycleline);
            else:
                print("\t" + "File not found: " + vmtcycleline);
    else:
        print("File not found: " + mdlcycleline);

		
		
		
print("\n\n Поиск контента для моделей закончен, поиск контента для карты... \n\n")
for materialsmapcycleline in getmaterialsfrommap(MAPFILE):
    if checkfile(CONTENTPATCH + "/" + materialsmapcycleline):
        print(materialsmapcycleline);
        if checkinmassive(materialsmapcycleline,allfileslist) == False:
            allfileslist.append(materialsmapcycleline);
        for vtfcycleline2 in getvtfromvmt(CONTENTPATCH + "/" + materialsmapcycleline):
            if checkfile(CONTENTPATCH + "/" + vtfcycleline2):
                print("\t" + vtfcycleline2);
                if checkinmassive(vtfcycleline2,allfileslist) == False:
                    allfileslist.append(vtfcycleline2);
            else:
                print("\t" + "File not found: " + vtfcycleline2);
    else:
        print("File not found: " + materialsmapcycleline);
		
allfileslist.sort();
allfolderslist = [];
for allfilescyclelist in allfileslist:
    fullpatch = OUTPUTCONTENTPATCH+"/"+allfilescyclelist;
    fullpatch2 = fullpatch.split('/');
    del fullpatch2[len(fullpatch2)-1]
    fullpatch3 = '/'.join(fullpatch2)
    if checkinmassive(fullpatch3,allfolderslist) == False:
        allfolderslist.append(fullpatch3);
allfolderslist.sort();
for kl in allfolderslist:
    checkandcreatefolders(kl);
# adding sw.vtx, vvd, dx80.vtx, dx90.vtx, phy
for allfilescyclelist2 in allfileslist:
    if allfilescyclelist2.find(".mdl") > -1:
        if checkfile(CONTENTPATCH+"/"+allfilescyclelist2.split('.')[0]+".vvd") == True:
            allfileslist.append(allfilescyclelist2.split('.')[0]+".vvd")
        if checkfile(CONTENTPATCH+"/"+allfilescyclelist2.split('.')[0]+".sw.vtx") == True:
            allfileslist.append(allfilescyclelist2.split('.')[0]+".sw.vtx")
        if checkfile(CONTENTPATCH+"/"+allfilescyclelist2.split('.')[0]+".dx80.vtx") == True:
            allfileslist.append(allfilescyclelist2.split('.')[0]+".dx80.vtx")
        if checkfile(CONTENTPATCH+"/"+allfilescyclelist2.split('.')[0]+".dx90.vtx") == True:
            allfileslist.append(allfilescyclelist2.split('.')[0]+".dx90.vtx")
        if checkfile(CONTENTPATCH+"/"+allfilescyclelist2.split('.')[0]+".phy") == True:
            allfileslist.append(allfilescyclelist2.split('.')[0]+".phy")
for allfilescyclelist3 in allfileslist:
     print(allfilescyclelist3);
     shutil.copy(CONTENTPATCH+"/"+allfilescyclelist3, OUTPUTCONTENTPATCH+"/"+allfilescyclelist3)
print("Контент сформирован");
